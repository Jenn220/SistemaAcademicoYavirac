export class PortafolioEntity {}
