export class CreatePortafolioDto {}
