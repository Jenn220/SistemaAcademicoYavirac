export class UpdatePortafolioDto {}
