export interface VinculacionRepository {}
