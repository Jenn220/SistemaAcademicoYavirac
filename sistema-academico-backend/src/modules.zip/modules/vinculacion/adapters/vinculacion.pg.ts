export class VinculacionPg {}
