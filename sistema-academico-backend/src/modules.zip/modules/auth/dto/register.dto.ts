export class RegisterDto {}
